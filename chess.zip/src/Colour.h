#ifndef COLOUR_H
#define COLOUR_H

enum class Colour {
    WHITE,
    BLACK,
    DRAW
};

#endif
