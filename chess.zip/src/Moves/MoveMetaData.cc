#include "MoveMetaData.h"

MoveMetaData::MoveMetaData(std::pair<Piece*, Piece*> capturedAndOriginalPawn, char pawnPromotion):capturedAndOriginalPawn{capturedAndOriginalPawn},pawnPromotion{pawnPromotion}{};